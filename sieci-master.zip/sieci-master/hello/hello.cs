﻿using System;
namespace hello_world
{
    class hello 
    {
        static void Main() 
        {
            Console.WriteLine("hello world"); 
        }
    }
}