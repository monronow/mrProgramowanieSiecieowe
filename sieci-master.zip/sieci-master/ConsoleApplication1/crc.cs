﻿ 



using System;
using System.Collections.Generic;
using System.Text;

namespace suma_kontrolna
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.Write("wpisz cos: ");
            String st;
            st = Console.ReadLine();
            byte[] bytes = Encoding.ASCII.GetBytes(st);
            byte checksum = 0;
            foreach (byte chData in bytes)
            {
                checksum += chData;
            }
            checksum &= 0x0001;
            Console.WriteLine(checksum.ToString());
        }
    } 
}
